import java.io.InputStream;
import java.util.Scanner;


public class order{
    // Greeting! And print out the restaurant name.
    public static void order(String[] args) {
        System.out.println("Hello Customer! Welcome to Happy Lamb Restaurants");
    }

    public static double order(InputStream in) {
        Scanner keyboard = new Scanner(in);
        return (0);
    }
}


