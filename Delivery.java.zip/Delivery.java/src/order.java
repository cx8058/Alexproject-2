public class order {
    public static void main(String[] args) {

        order(System.in);
    }

}
    Scanner scan = new scanner (System.in);
    System.out.println('Would you like to tip? ')
    }